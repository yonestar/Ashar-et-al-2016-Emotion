module QMeasureHelper
end
