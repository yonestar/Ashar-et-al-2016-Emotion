class LastLevel < ActiveRecord::Base
  belongs_to :element
  belongs_to :session
end
