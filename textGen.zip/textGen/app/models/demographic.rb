class Demographic < ActiveRecord::Base
  
  belongs_to :survey
  
end
