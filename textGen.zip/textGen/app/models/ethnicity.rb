class Ethnicity < ActiveRecord::Base
	has_many :images
end
