require 'test_helper'

class SessionControllerTest < ActionController::TestCase
  test "should get disp" do
    get :disp
    assert_response :success
  end

end
