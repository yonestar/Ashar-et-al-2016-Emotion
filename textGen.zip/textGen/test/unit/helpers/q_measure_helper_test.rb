require 'test_helper'

class QMeasureHelperTest < ActionView::TestCase
end
