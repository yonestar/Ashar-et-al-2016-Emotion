require 'test_helper'

class SessionHelperTest < ActionView::TestCase
end
