#
#   PARSE MEASURES
#
#
measures = Dir["#{RAILS_ROOT}/db/measures/*txt"]
measures.each { |f|
  
  data = {}
  n_scales, n_items = 0, 0
  
  # Read in all data for measure--key/value pairs in .txt file
  File.new(f).read.split(/[\r\n]+/).each { |l|
    l.strip!
    next if l !~ /(.*?):\s+(.*)/
    data[$1.downcase] = $2
  }
  
  # Skip if no measure name found, or if already in DB
  next if !data.key?('name') or QMeasure.find_by_name(data['name'])
  
  # Create measure
  m = QMeasure.new(:name => data['name'], :instructions => data['instructions'], :description => (data['description'] || ''), :anchors => data['anchors'], :response_style => data['responsestyle'])
  
  #if m.name == 'Target Ratings'
	#  print = true
	#else
	print = false
	#end
  
  abort("Error: Couldn't save measure #{m.name}!") if !m.save!
  
  # Map items
  items = []
  item_rows = data.keys.select { |k| k =~ /^item/ }.sort_by { |e| e[/\d+/].to_i }
  item_rows.each { |i|
    idata = data[i].split(/\t/)
    item = QItem.new(:text => idata[0])
    # If > 1 value in array, set item-wise response style and anchors
    item.attributes = {:response_style => idata[1], :anchors => idata[2]} if idata.size > 1
    items << item if item.save!
  }
  
  # Map scales
  scale_rows = data.keys.select { |k| k =~ /^scale/ }.sort
  scale_rows.each { |i|
    key = data[i].split(/[,\s]+/)
    name = key.shift
    s = QScale.new(:name => name)
    p 'SCALE ' + name + ' ' + key.to_s if print 
    key.each { |k|
      id = k[/\d+/].to_i
      q_item_id = items[id-1].id
      keying = (k =~ /R/) ? -1 : 1
      p k + ' ' + q_item_id.to_s + ' ' + keying.to_s if print
      s.q_assignments << QAssignment.new(:q_item_id => q_item_id, :keying => keying, :q_measure_id => m.id)
    }
    s.n_items = s.q_assignments.size
    m.q_scales << s
  }
  
  # If there aren't any scales, we just assign items directly to measure
  m.q_items = items if m.q_scales.empty?

 # Counts
  m.n_items = items.size
  m.n_scales = m.q_scales.size
  
  if m.save!
    puts "Successfully saved measure #{m.name}..."
  else
    puts "Error! Couldn't save measure #{m.name}!"
    exit
  end

}



#
# PARSE TARGETS SEEDS
#
#   

def parse(fname)
	seedFilesDir = RAILS_ROOT + '/db/targetSeeds/'
	filename = seedFilesDir + fname
	contents = IO.readlines(filename) #File.create(filename).readlines
	i = 0
	contents.each { |line|
		next if line.strip == ''
		next if line.starts_with?('#')
		i += 1
		
		yield line
	}
	print fname + ': ' + i.to_s + ' items inserted' + "\n"
end

  #### HARDSHIP #######
parse("hardships.txt")  { |line|
	parts = line.split(',')
	Hardship.create({:name => parts[0].strip, :description => parts[1].strip, :charity_name => parts[2].strip, :charity_url => parts[3].strip}).save
}

  #### ELEMENTS #######
parse('elements.txt') { |line|
	parts = line.split
	el = Element.create({:name => parts[0], :numLevels => parts[1], :weight => parts[2], :hasHardship => (((parts[3] =~ /y/i) != nil) ? true : false)})
	el.save
}

  #### SENTENCES #######
parse("sentences.txt") { |line|
	parts = line.split(' ', 5)
	
	parts[1] = nil if (parts[1] =~ /null/i) != nil
	
	sent = Sentence.create({:text => parts[4].strip, :level => parts[3], :subcat => parts[1]})
	el = Element.find_by_name(parts[0])
	p 'HEY_' + parts[0].to_s if el == nil
	sent.element = el
	el.sentences << sent
	hard = Hardship.find_by_name(parts[2])
	
	if (hard != nil) 
		sent.hardship = hard
		hard.sentences << sent
		hard.elements << el if !hard.elements.include?(el) #WIRING BOTH WAYS SEEMS TO CAUSE DUPLICATION (?!)
		hard.save
	end
	
	sent.save
	el.save
}

## ETHNICITIES ##
parse("ethnicities.txt") { |line|
	parts = line.split
	Ethnicity.create({:code => parts[0], :ethnicity => parts[1]})
}

## IMAGES ##
parse("images.txt") { |line|
	parts = line.split(',')
	img = Image.create({:file => parts[0], :attribution => parts[4].strip, :gender => (((parts[2] =~ /m/i) != nil) ? true : false)})
	img.ethnicity = Ethnicity.find_by_code(parts[1].strip.capitalize)
	img.save
}

parse("names.txt") { |line|
	parts = line.split(/\s\s+/) # at least two spaces!
	parts.each_with_index { |p,i|  parts[i] = parts[i].strip}
	Name.create({:name => parts[0], :gender => (((parts[1] =~ /m/i) != nil) ? true : false), :ethnicity => parts[2]})
}


 ## ERROR CHECKING ##
 Element.find(:all).each { |el|
 	print '###WARNING: ' + el.name + " has no sentences!\n" if el.sentences.size == 0
 }
  Hardship.find(:all).each { |h|
 	print  '###WARNING: ' + h.name + " has no elements!\n" if h.elements.size == 0
 }
 Ethnicity.all.each { |eth|
 	print '###WARNING: ' + eth.ethnicity + " has no sentences!\n" if Sentence.find_by_subcat(eth.code) == nil
 }