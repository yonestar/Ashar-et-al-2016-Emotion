#require 'active_record'
#gem 'transitions', :require => ["transitions", "active_record/transitions"]
require 'rubygems'
require 'bundler/setup'


require 'mysql'
require 'active_record'
require 'active_record/transitions'
require 'transitions'

HOSTNAME = "canlab.colorado.edu"
USERNAME = "yoni"
PASSWORD = "c0mpassi0n"
DATABASE = "textGen"


ActiveRecord::Base.establish_connection(
  :adapter  => "mysql",
  :database => DATABASE,
  :username => USERNAME,
  :password => PASSWORD,
  :host => HOSTNAME
)
@db = Mysql.new(HOSTNAME, USERNAME, PASSWORD, DATABASE)


# hack to get active record working...
$MODELDIR = '/Users/yoni/apps/textGen/app/models/*.rb'
Dir.glob($MODELDIR).each{ |file|
	require file
	p file
}



def save_table(name)
  res = @db.query("SELECT * FROM #{name}")
  buffer = [res.fetch_fields.map { |f| f.name }.join("\t")]
  res.each { |r| buffer << r.join("\t") }
  File.new("#{name}.txt",'w').puts buffer
end

def save_ambi
res = @db.query("select * from
q_item_scores
where q_item_scores.q_item_id between 1 and 181")
  buffer = [res.fetch_fields.map { |f| f.name }.join("\t")]
  res.each { |r| buffer << r.join("\t") }
  File.new("ambi.csv",'w').puts buffer
end


def filePerTable
	my = Mysql::new("127.0.0.1", "compassion", "meditation", "textGen")
	table_names = ['elements', 'demographics', 'ethnicities', 'images', 'q_assignments', 'q_item_scores', 'q_items', 'q_measures', 'q_scale_scores', 'q_scales', 'sentence_targets', 'sentences', 'sessions', 'surveys', 'targets']

	table_names.each { |t|
		save_table t
	}
end


def approvals
	outf = File.open('myFiles/approval.csv', 'w')
	SessionState.find_all_by_state('done').each { |sess|
		outf.write([sess.id.to_s, sess.code, sess.response_cms.size].join("\t") + "\n")
	}
end

def eth_code(string)
	return '1' if !(string =~ /black/i).nil? || string == 'B'
	return '2' if !(string =~ /white/i).nil? || string == 'W'
	return '3' if !(string =~ /asian/i).nil? || string == 'A'
	return '4' if !(string =~ /native/i).nil? 
	return '5' if !(string =~ /other/i).nil? 
	return '6' if !(string == 'Hispanic').nil? || string == 'L'
	p 'unknown!!!'
	p val
	return '9'
end

def gender_code(val)
	return '1' if (val == true) || !(val =~ /^male/i).nil?
	return '2' if (val == false) || !(val =~ /female/i).nil?
	p 'unknown!!!'
	p val
	return '3'
end

def relig_code(val)
  return '1' if val == "Christian"
  return '2' if val == "Muslim"
  return '3' if val == "Jewish"
  return '4' if val == "Buddhist"
  return '5' if val == "Atheist"
  return '6' if val == "Hindu"
  #7 means spiritual NOS, like teaches meditation, or serves veggie meals at temple
  return '8' if val == "Other" #user entered Other
  return '9' #user didn't answer the q  
end


#2 on nil, 1 on high is true, -1 on high is false
def code_val(val)
	return 2 if val.nil?
	val ? 1 : -1
end

#
#
# SEE csvGen_old.rb for a function that outputs scores on a rating by rating basis (all 23 ratings)
#  that file also has some other functions that maybe are of interest
#
#


## creates two files
## 1: wideForm2.csv:
## for each session who has met all criteria in first Session block below
## create a long form row for them, including subj/targ/ratings/donation/sentences/eth and gender for subj and for targ
## initialize missing values to 0 and impute them later.
## 2:  traits.csv
#  each subject's personality data
def wide_form2()
	
	p 'hey you!  targ_religion is totally screwy now!  gotta change the database high sentence.high to something other than TINYINT, which evaluates as a boolean!'

	basedir = '/Users/yoni/apps/textGen/'

	# outfile and header for wideform.csv
	outf = File.open(basedir + 'wideForm2.csv', 'w')
	header = ['index', 'session_id', 'target_id', 'PosEmpathy', 'NegEmpathy', 'InternalSimilarity', 
      'ExternalSimilarity', 'Neediness', 'Responsibility', 'Likability', 'DonationScale',
      'donation',
      'hardship', 'sent1', 'sent2', 'sent3', 
      'subj_eth', 'subj_gender', 'subj_religion', 'target_eth', 'target_gender', 'targ_relig', 
      'target_image_id', 'target_name_id']
	outf.write("** Index is sequential, session is actual subj number. For religion: 1=Christian,2=nonChristian,3=unspecified.  Gender: Male=1, Female=2.  Ethnicity: 1=black,2=white,3=other\n")
	outf.write(header.join(',') + "\n")

	
	#outfile for target_ratings.csv scores
	header = @db.query('select text from q_items where id >= 253 order by id')
	outf_qi = File.open(basedir + 'target_ratings.csv', 'w')
	hdr = ['index', 'subject', 'target_id']
	header.each { |col| hdr << col[0].gsub(/[?'.,']/, '').gsub(/\s/,'') }
	outf_qi.write hdr.join(',') + "\n"


	#outfile and header for traits
	outf_traits = File.open(basedir + 'traits.csv', 'w')	
	header = ['index', 'session_id']
	header << QScale.where("id <= 216").map { |scale| scale.name} #scale names
	outf_traits.write(header.join(',') + "\n")

    
    #find elements of interest for later use
	relig_el = Element.find_by_name('religion')
	
	#only take sessions that:
	#  made it to the end of the task ('done')
	#  answered the vast majority of the questions about the targets
	#  answered about their gender.
	#  Also, droppping another two, don't remember why
	sessions = []
	Session.all.each { |sess|
		sessions << sess if sess.state == 'done' and sess.survey.q_item_scores.size > 610 and sess.id != 432 and sess.id != 245 and !sess.survey.demographic.gender.empty? #messed up subj
	}


	p 'I made it!'

	sessions.each_with_index { |sess, index|

	
		## ITEM SCORES -- target_ratings.csv
		#index, session, target id, 23 items
		scores = sess.survey.q_item_scores
		targs_items = Hash.new
		scores.each { |q_item|			  
		    next if q_item.target_id.nil? # this q_item is trait data, not target data
    
		    #initialize this target's q_items if new.  initialize to 0 so can impute later
		    targs_items[q_item.target_id] = Array.new(23, 0) if !targs_items.has_key?(q_item.target_id) 
	        targs_items[q_item.target_id][q_item.q_item_id - 253] = q_item.response #253 is id of lowest item

    	}
  
    	# write item data to target_ratings.csv
		targs_items.each { |targ_id, targ_resps|
			outf_qi.write [index, sess.id, targ_id].concat(targ_resps).join(',') + "\n"
		}

next
p "boo"


		# main block for wideform.csv 
		sess.survey.targets.each { |targ|
	
			# SCALE SCORES: wideForm2.csv
			resps = sess.survey.q_scale_scores.find_all_by_target_id(targ)

	
			#error checking
			stop = false
			resps.each { |resp| stop = true if resp.score.nil?}	
			if stop #missing scales
				p sess.id.to_s + ' with targ ' + targ.id.to_s + ' is missing a scale score'  
				next 
			end
			if sess.survey.demographic.gender.empty?
				p 'No gender: ' + sess.id.to_s
				next
			end
			
			## wideform.csv has the following columns:
			# first 3: sess and targ id
			# next 15: 8 rating scales, 1 donation, 2 race, 2 gender, 2 relig
			# next 4:  targ bio sentence ids, 1 for hardship and 3 descriptors
			# and 1 more for photo  id
			# allocate space for a new row, and assign first three cols which we already know
			rowdata = [] #Array.new(3 + 15 + 4 + 1, '0') #initialize ratings to 0; impute all 0's later
			rowdata << index
			rowdata << sess.id
			rowdata << targ.id
						
			# put 8 rating in their place in rowdata (the variable for "this row"). 217 is id of first q_scale
			8.times { rowdata << '0'} #first put in zeros, so if missing will be imputed later
			resps.each { |resp|	rowdata[resp.q_scale_id - 217 + 3] = resp.score	}
		    
			# donation
			don_item = (r = sess.survey.q_item_scores.find_by_q_item_id_and_target_id(275, targ.id))
			if don_item.nil? 
				rowdata <<  0 #put 0 (which is like NaN) for no donation
				p 'no donation for ' + rowdata[0..3].to_s
			else 
				rowdata << don_item.response
			end

			# target info
			targ_relig = '3' #default: no religion specified
			rowdata << targ.hardship.id #hardship
			targ.sentences.each { |sent| # 3 sentences
				rowdata << sent.id
#				p sent.high.to_s()  if sent.element == relig_el
				targ_relig = code_val(sent.high) if sent.element == relig_el  #set targ_relig to 1 if this is a Christian sentence or 2 if specifies a nonChristian religion
			}

			##ingroup/outgroup:  eth/gender/relig, first for subj and then for targ
			rowdata << eth_code(sess.survey.demographic.race)
			rowdata << gender_code(sess.survey.demographic.gender)
			rowdata << relig_code(sess.survey.demographic.religion)
			
			rowdata << eth_code(targ.image.ethnicity.code)
			rowdata << gender_code(targ.image.gender)
			rowdata << targ_relig

			rowdata << targ.image.id #image
			rowdata << targ.name.id #name

			
			#write the row data	for wide_form.csv	
			outf.write(rowdata.join(',') + "\n")



  

		}


		## NOW WRITE THE TRAIT INFO FOR THIS SUBJ, INTO SEPARATE FILE
		#all the scales for this subj, ordered by scale id
		scales = sess.survey.q_scale_scores.where('q_scale_id <= 216').order(:q_scale_id)
 		print "INCOMPLETE!!  session " + sess.id + " has " + scales.size + " scales." if scales.size < 216
	  
	 	#write all the scales, joined by a comma, to the file
	 	rowdata = []
	 	rowdata <<  index
		rowdata << sess.id
	 	rowdata << scales.map{ |scale| scale.score}
	 	outf_traits.write rowdata.join(',') + "\n"
  	}
		
	
	outf.flush
	outf.close
end

# call the desired function
wide_form2()
