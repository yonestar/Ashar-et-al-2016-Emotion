# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20110719165418) do

  create_table "demographics", :force => true do |t|
    t.string   "race"
    t.string   "religion"
    t.string   "gender"
    t.string   "marital"
    t.integer  "age"
    t.integer  "survey_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "donations", :force => true do |t|
    t.integer  "session_id"
    t.integer  "hardship_id"
    t.float    "amount"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "elements", :force => true do |t|
    t.string   "name"
    t.string   "numLevels"
    t.boolean  "hasHardship"
    t.float    "weight"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "elements_hardships", :id => false, :force => true do |t|
    t.integer "hardship_id"
    t.integer "element_id"
  end

  create_table "ethnicities", :force => true do |t|
    t.string   "ethnicity"
    t.string   "code"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "hardships", :force => true do |t|
    t.string   "name"
    t.string   "description"
    t.string   "charity_name"
    t.string   "charity_url"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "images", :force => true do |t|
    t.string   "file"
    t.integer  "ethnicity_id"
    t.boolean  "gender"
    t.string   "attribution"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "last_levels", :force => true do |t|
    t.integer  "element_id"
    t.integer  "session_id"
    t.integer  "level"
    t.integer  "first_level"
    t.string   "subcat"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "names", :force => true do |t|
    t.string   "name"
    t.boolean  "gender"
    t.string   "ethnicity"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_assignments", :force => true do |t|
    t.integer  "q_item_id"
    t.integer  "q_scale_id"
    t.integer  "q_measure_id"
    t.integer  "keying"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_item_scores", :force => true do |t|
    t.integer  "response"
    t.integer  "survey_id"
    t.integer  "q_item_id"
    t.integer  "target_id"
    t.text     "text"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_item_sets", :force => true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_items", :force => true do |t|
    t.string   "ipip_id"
    t.string   "source"
    t.string   "response_style"
    t.text     "text"
    t.text     "anchors"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_measures", :force => true do |t|
    t.string   "name"
    t.string   "response_style"
    t.text     "instructions"
    t.text     "anchors"
    t.text     "description"
    t.integer  "n_scales"
    t.integer  "n_items"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_scale_scores", :force => true do |t|
    t.integer  "survey_id"
    t.integer  "target_id"
    t.integer  "q_scale_id"
    t.integer  "n_answered"
    t.float    "score"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "q_scales", :force => true do |t|
    t.string   "name"
    t.string   "display"
    t.text     "desc"
    t.integer  "q_measure_id"
    t.integer  "n_items"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sentence_targets", :force => true do |t|
    t.integer  "order"
    t.integer  "sentence_id"
    t.integer  "target_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sentences", :force => true do |t|
    t.integer  "level"
    t.string   "subcat"
    t.text     "text"
    t.integer  "element_id"
    t.integer  "hardship_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "sessions", :force => true do |t|
    t.string   "state"
    t.text     "properties"
    t.string   "completion_code"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "surveys", :force => true do |t|
    t.string   "code"
    t.text     "data"
    t.text     "state"
    t.integer  "session_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "targets", :force => true do |t|
    t.integer  "image_id"
    t.integer  "hardship_id"
    t.integer  "name_id"
    t.integer  "survey_id"
    t.text     "bio"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

end
