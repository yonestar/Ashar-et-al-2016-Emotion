class CreateSentences < ActiveRecord::Migration
  def self.up
    create_table :sentences do |t|
      t.integer :level
      t.string :subcat
      t.text :text
	  t.references :element
	  t.references :hardship
	  t.boolean :high
      t.timestamps
      
 
      
    end
  end
  
end
