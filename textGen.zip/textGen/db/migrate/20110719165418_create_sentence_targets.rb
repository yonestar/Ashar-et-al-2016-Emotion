class CreateSentenceTargets < ActiveRecord::Migration
  def self.up
    create_table :sentence_targets do |t|
      t.integer :order
      t.references :sentence
      t.references :target

      t.timestamps
    end
  end

  def self.down
    drop_table :sentence_targets
  end
end
