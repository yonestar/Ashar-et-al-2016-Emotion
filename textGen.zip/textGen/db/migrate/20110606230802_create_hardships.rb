class CreateHardships < ActiveRecord::Migration
  def self.up
    create_table :hardships do |t|
      t.string :name
	  t.string :description
	  t.string :charity_name
	  t.string :charity_url
      t.timestamps
    end
    
    create_table :elements_hardships, :id => false do |t|
      t.references :hardship
      t.references :element
    end
    
  end

  def self.down
    drop_table :hardships
    drop_table :elements_hardships
  end
end
