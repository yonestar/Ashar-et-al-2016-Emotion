class CreateTargets < ActiveRecord::Migration
  def self.up
    create_table :targets do |t|
      t.references :image
      t.references :hardship
      t.references :name
      t.references :survey
      t.text :bio

      t.timestamps
    end
  end

  def self.down
    drop_table :targets
  end
end
