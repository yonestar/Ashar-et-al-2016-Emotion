class CreateDemographics < ActiveRecord::Migration
  def self.up
    create_table :demographics do |t|
      t.string :race, :religion, :gender, :marital
      t.integer :age
      t.references :survey
      t.timestamps
    end
  end

  def self.down
    drop_table :demographics
  end
end
