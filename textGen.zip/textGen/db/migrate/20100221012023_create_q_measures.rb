class CreateQMeasures < ActiveRecord::Migration
  def self.up
    create_table :q_measures do |t|
      t.string  :name, :response_style
      t.text :instructions, :anchors, :description
      t.integer :n_scales, :n_items
      t.timestamps
    end
  end

  def self.down
    drop_table :q_measures
  end
end
