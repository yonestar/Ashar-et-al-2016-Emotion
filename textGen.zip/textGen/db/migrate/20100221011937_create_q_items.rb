class CreateQItems < ActiveRecord::Migration
  def self.up
    create_table :q_items do |t|
      t.string :ipip_id, :source, :response_style
      t.text :text, :anchors
      t.timestamps
    end
  end

  def self.down
    drop_table :q_items
  end
end
