class CreateQAssignments < ActiveRecord::Migration
  def self.up
    create_table :q_assignments do |t|
      t.references :q_item, :q_scale, :q_measure 
      t.integer :keying
      t.timestamps
    end
  end

  def self.down
    drop_table :q_assignments
  end
end
