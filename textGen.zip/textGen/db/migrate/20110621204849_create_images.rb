class CreateImages < ActiveRecord::Migration
  def self.up
    create_table :images do |t|
      t.string :file
      t.references :ethnicity
      t.boolean :gender
	  t.string :attribution
      t.timestamps
    end
  end

  def self.down
    drop_table :images
  end
end
