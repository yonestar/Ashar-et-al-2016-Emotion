class CreateQScaleScores < ActiveRecord::Migration
  def self.up
    create_table :q_scale_scores do |t|
      t.references :survey, :target, :q_scale
      t.integer :n_answered
      t.float :score
      t.timestamps
    end
  end

  def self.down
    drop_table :q_scale_scores
  end
end
