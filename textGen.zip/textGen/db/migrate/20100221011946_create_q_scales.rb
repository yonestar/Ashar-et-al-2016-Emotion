class CreateQScales < ActiveRecord::Migration
  def self.up
    create_table :q_scales do |t|
      t.string  :name, :display
      t.text    :desc
      t.references :q_measure
      t.integer :n_items
      t.timestamps
    end
  end

  def self.down
    drop_table :q_scales
  end
end
