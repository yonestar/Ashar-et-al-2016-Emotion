class CreateQItemSets < ActiveRecord::Migration
  def self.up
    create_table :q_item_sets do |t|

      t.timestamps
    end
  end

  def self.down
    drop_table :q_item_sets
  end
end
