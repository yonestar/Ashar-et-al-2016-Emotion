class CreateLastLevels < ActiveRecord::Migration
  def self.up
    create_table :last_levels do |t|
      t.references :element
      t.references :session
      t.integer :level
      t.integer :first_level
      t.string :subcat

      t.timestamps
    end
  end

  def self.down
    drop_table :last_levels
  end
end
