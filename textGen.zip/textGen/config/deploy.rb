$:.unshift(File.expand_path('./lib', ENV['rvm_path'])) # Add RVM's lib directory to the load path.
# require 'bundler/capistrano'
require 'rvm/capistrano'  # Load RVM's capistrano plugin.
set :rvm_ruby_string, 'ruby-1.9.2-p180@rails3'        # Or whatever env you want it to run in.
set :rvm_type, :user

set :application, "neurosynth"
set :repository,  "ssh://websites@canlab.colorado.edu/~websites/apps/textGen/.git"

set :scm, :git
# Or: `accurev`, `bzr`, `cvs`, `darcs`, `git`, `mercurial`, `perforce`, `subversion` or `none`

set :domain, "canlab.colorado.edu"   #the one you ssh into
set :user, "websites"            #the user you created when setting up the domain (has to have shell access)
set :application, "textGen"          #the name of the folder you chose when setting up the domain
set :applicationdir, "/Volumes/RAID1/websites/rails/apps/textGen"

# deploy config
set :use_sudo, false
set :deploy_to, applicationdir       # Where on the server your app will be deployed
set :branch, 'master'
# set :scm_verbose, true
# set :use_sudo, true
set :keep_releases, 3
default_run_options[:pty] = true
# set :ssh_options, {:forward_agent => true}

role :web, "canlab.colorado.edu"                          # Your HTTP server, Apache/etc
role :app, "canlab.colorado.edu"                          # This may be the same as your `Web` server
role :db,  "canlab.colorado.edu", :primary => true # This is where Rails migrations will run

set :deploy_via, :remote_cache
set :copy_exclude, [".git", "spec"]

# set :default_environment, {
#   'PATH' => "/Users/websites/.rvm/gems/ruby-1.9.2-p180@rails3/bin:/Users/websites/.rvm/bin:/Users/websites/.rvm/rubies/ruby-1.9.2-p180/bin:$PATH",
#   'RUBY_VERSION' => 'ruby 1.9.2',
#   'GEM_HOME'     => '/Users/websites/.rvm/gems/ruby-1.9.2-p180@rails3',
#   'GEM_PATH'     => '/Users/websites/.rvm/gems/ruby-1.9.2-p180@rails3',
#   'BUNDLE_PATH'  => '/Users/websites/.rvm/gems/ruby-1.9.2-p180@rails3'  # If you are using bundler.
# }

# Passenger
namespace :deploy do
  task :start do ; end
  task :stop do ; end
  task :restart, :roles => :app, :except => { :no_release => true } do
    run "#{try_sudo} touch #{File.join(current_path,'tmp','restart.txt')}"
  end
end

after "deploy", "deploy:cleanup"