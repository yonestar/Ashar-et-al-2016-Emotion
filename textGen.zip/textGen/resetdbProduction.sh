#!/bin/bash

rake RAILS_ENV=production db:drop
rake RAILS_ENV=production db:create
rake RAILS_ENV=production db:migrate
rake RAILS_ENV=production db:seed
